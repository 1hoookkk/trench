# SKILL.md — Z-Plane Filter Implementation

## When to Use This Skill

Use when building:
- Formant/vowel filters (parallel resonator banks)
- Morphing Z-Plane filters (E-mu style)
- High-Q resonant filter banks
- Any 14-pole filter architecture

---

## The Non-Negotiables

### 1. TOPOLOGY SEMANTICS

```cpp
// CASCADE: Unused stage = BYPASS (identity, passes signal)
// PARALLEL: Unused stage = MUTE (outputs ZERO)

// THIS IS THE #1 BUG IN FAILED IMPLEMENTATIONS
// If parallel bypass outputs signal, you add raw input to the sum
// and formants become inaudible under broadband noise
```

**Implementation:**

```cpp
float processParallel(double x) {
    double sum = 0.0;
    for (int i = 0; i < NUM_STAGES; ++i) {
        if (!active_[i]) continue;  // MUTE: skip entirely
        sum += weights_[i] * processBiquad(i, x);
    }
    return sum;
}

float processCascade(double x) {
    double y = x;
    for (int i = 0; i < NUM_STAGES; ++i) {
        // Bypass stages pass through (b0=1, rest=0)
        y = processBiquad(i, y);
    }
    return y;
}
```

---

### 2. GAIN ARCHITECTURE (The E-mu Secret)

Gain is NOT just "b0 normalization." It's a complete pipeline:

```
INPUT
  │
  ├─► Pre-Gain (drive)
  │
  ▼
┌─────────────────────────────────────┐
│  Resonator Bank                     │
│  (each stage has its own weight)    │
└─────────────────────────────────────┘
  │
  ├─► Weighted Sum: Σ(w[i] × y[i])
  │
  ├─► Power Normalization: sum / √(Σw²)
  │
  ├─► Bandwidth Compensation: × √(Bref / Bw)  ← THE KEY
  │
  ├─► Makeup Gain
  │
  ├─► Soft Clip (saturation)
  │
  ▼
OUTPUT
```

**Why bandwidth compensation exists:**

```
R = 0.998 at 48kHz → Bandwidth ≈ 30 Hz
Each formant passes only 30 Hz of noise power
That's 1/10th what a "normal" 300 Hz filter passes
Without compensation: -10 dB per formant = inaudible

g_bw = sqrt(300 / 30) = 3.16 (+10 dB)
```

**Implementation:**

```cpp
float processSample(float input) {
    double x = input * drive_;
    
    // Parallel sum with weights
    double sum = 0.0;
    double weightSumSq = 0.0;
    
    for (int i = 0; i < NUM_STAGES; ++i) {
        if (!active_[i]) continue;
        
        double y = processBiquad(i, x);
        sum += weights_[i] * y;
        weightSumSq += weights_[i] * weights_[i];
    }
    
    // Power normalization
    double y_norm = sum / (std::sqrt(weightSumSq) + 1e-12);
    
    // Bandwidth compensation
    double bw = -std::log(avgRadius_) * sampleRate_ / PI;
    double g_bw = std::sqrt(bwRef_ / bw);
    
    // Makeup + saturation
    return saturate(y_norm * g_bw * makeupGain_);
}
```

---

### 3. RESONATOR COEFFICIENTS

**For formants (parallel topology):**

```cpp
// Zeros at DC and Nyquist for clean sweeping
// b0 = g(1-R), b1 = 0, b2 = -g(1-R)
// where g is the per-stage gain (usually 1.0, loudness handled elsewhere)

static Biquad designResonator(double freq, double bandwidth, double sr) {
    double theta = 2.0 * PI * freq / sr;
    double R = std::exp(-PI * bandwidth / sr);
    
    double g = 1.0;  // Per-stage gain (adjust via weights, not here)
    double c = g * (1.0 - R);
    
    Biquad b;
    b.b0 = c;
    b.b1 = 0.0;
    b.b2 = -c;
    b.a1 = -2.0 * R * std::cos(theta);
    b.a2 = R * R;
    return b;
}
```

**For allpass (cascade topology / phasers):**

```cpp
static Biquad designAllpass(double freq, double bandwidth, double sr) {
    double theta = 2.0 * PI * freq / sr;
    double R = std::exp(-PI * bandwidth / sr);
    
    Biquad b;
    b.b0 = R * R;
    b.b1 = -2.0 * R * std::cos(theta);
    b.b2 = 1.0;
    b.a1 = b.b1;
    b.a2 = b.b0;
    return b;
}
```

---

### 4. SATURATION PLACEMENT

**Two saturation points for E-mu character:**

```cpp
// 1. Per-stage: "chew" / state conditioning
double processBiquad(int i, double x) {
    const Biquad& b = stages_[i];
    
    double y = b.b0*x + b.b1*x1_[i] + b.b2*x2_[i]
             - b.a1*y1_[i] - b.a2*y2_[i];
    
    x2_[i] = x1_[i];
    x1_[i] = x;
    y2_[i] = y1_[i];
    y1_[i] = saturateLight(y);  // Light saturation in feedback
    
    return y;
}

// 2. Post-sum: containment
output = saturate(sum * g_bw * makeupGain_);
```

**Saturation functions:**

```cpp
// Light (per-stage): just tames extremes
inline double saturateLight(double x) {
    return x - (x * x * x) * 0.1;  // Gentle cubic
}

// Full (post-sum): Dattorro
inline double saturate(double x) {
    if (x > 1.0) return 0.6666667;
    if (x < -1.0) return -0.6666667;
    return x - (x * x * x) / 3.0;
}
```

---

### 5. MORPH INTERPOLATION

**NEVER interpolate coefficients directly.**

```cpp
// Interpolate in perceptual space, regenerate coefficients

// FREQUENCY: Logarithmic (pitch-linear)
double freq = freqA * pow(freqB / freqA, t);

// RADIUS: Geometric (decay-linear)
double R = pow(R_A, 1.0 - t) * pow(R_B, t);

// WEIGHTS: Linear
double w = wA * (1.0 - t) + wB * t;

// Then regenerate coefficients from freq, R
double theta = 2.0 * PI * freq / sampleRate;
a1 = -2.0 * R * cos(theta);
a2 = R * R;
// etc.
```

**Topology transitions: Crossfade outputs**

```cpp
if (topologyA != topologyB) {
    double yA = processParallel(x);
    double yB = processCascade(x);
    return (1.0 - t) * yA + t * yB;
}
```

---

### 6. FRAME STRUCTURE

```cpp
struct Pole {
    double freq;      // Hz
    double radius;    // 0.0 - 0.999
    double weight;    // Per-formant loudness (typically 1.0)
    bool active;      // false = muted in parallel, bypass in cascade
};

struct FilterFrame {
    Pole poles[7];
    Topology topology;    // PARALLEL or CASCADE
    double frameGain;     // Overall frame loudness
};

struct FilterCube {
    FilterFrame corners[8];  // 8 corners of morph cube
    
    FilterFrame interpolate(float f, float m, float t);
};
```

---

### 7. RECOMMENDED VALUES

| Parameter | Value | Notes |
|-----------|-------|-------|
| Bandwidth (vowels) | 15-25 Hz | Gives R ≈ 0.998, the "ring" |
| Bandwidth ref | 300 Hz | For loudness compensation |
| Pre-gain | 1.0 | Don't attenuate input |
| Makeup gain | 4.0 - 8.0 | Depends on formant count |
| Weights | 1.0 each | Unless specific formant emphasis |
| Control rate | 32 samples | Coefficient update interval |

---

## Common Bugs

### Bug 1: Parallel bypass adds dry signal
```cpp
// WRONG: Bypass stage in parallel mode
if (bypass) return x;  // Adds raw input to sum!

// RIGHT: Skip the stage entirely
if (!active_[i]) continue;
```

### Bug 2: No bandwidth compensation
```cpp
// WRONG: Just sum and output
return sum * makeupGain_;

// RIGHT: Compensate for narrow bandwidth
double g_bw = sqrt(bwRef / bw);
return sum * g_bw * makeupGain_;
```

### Bug 3: State variable update order
```cpp
// WRONG:
y1_[i] = saturate(y);
y2_[i] = y1_prev_[i];  // Stale value!

// RIGHT:
y2_[i] = y1_[i];       // Save old first
y1_[i] = saturate(y);  // Then update
```

### Bug 4: Coefficient interpolation
```cpp
// WRONG: Linear interpolation of a1, a2
a1 = lerp(a1_A, a1_B, t);  // Can go unstable!

// RIGHT: Interpolate freq/radius, regenerate
freq = freqA * pow(freqB / freqA, t);
R = pow(R_A, 1.0-t) * pow(R_B, t);
a1 = -2.0 * R * cos(2.0 * PI * freq / sr);
```

---

## Verification Pipeline

### Test 1: White Noise → Vowel
```
Input: White noise
Filter: "Ah" vowel (F1=730, F2=1090, F3=2440, F4=3500, BW=18)
Expected: Clearly audible "ahh" character
If faint: Bandwidth compensation missing or bypass bug
```

### Test 2: Spectrum Analyzer
```
Expected peaks at formant frequencies
Peak heights should be roughly equal (±6dB)
If one dominates: Weight or gain issue
```

### Test 3: Morph Stability
```
Morph Ah → Ee at 0.5 Hz
Listen for: Smooth transition, no clicks, no volume dips
If unstable: Coefficient interpolation bug
```

### Test 4: Null Test (1:1 verification)
```
Record hardware/reference output
Level-match your output
Invert and sum
Residual should be noise floor only
```

---

## Signal Flow Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                        FIELD ENGINE                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  INPUT ──► [Drive] ──┬──► Biquad 0 ──► [Sat] ──┬               │
│                      │                         │               │
│                      ├──► Biquad 1 ──► [Sat] ──┤               │
│                      │                         │               │
│                      ├──► Biquad 2 ──► [Sat] ──┼──► [Σ w×y]   │
│                      │                         │       │       │
│                      ├──► Biquad 3 ──► [Sat] ──┤       │       │
│                      │                         │       ▼       │
│                      ├──► (muted) ─────────────┤   [Power     │
│                      │                         │    Norm]      │
│                      ├──► (muted) ─────────────┤       │       │
│                      │                         │       ▼       │
│                      └──► (muted) ─────────────┘   [BW Comp]   │
│                                                        │       │
│                                                        ▼       │
│                                                   [Makeup]     │
│                                                        │       │
│                                                        ▼       │
│                                                   [Saturate]   │
│                                                        │       │
│                                                        ▼       │
│                                                     OUTPUT     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Quick Start

```cpp
// 1. Configure vowel
ZPlaneCore core;
core.setTopology(Topology::PARALLEL);
core.setSampleRate(48000.0);
core.setBandwidthRef(300.0);  // For loudness compensation

// 2. Set formants
core.setStage(0, designResonator(730, 18, 48000), 1.0, true);   // F1
core.setStage(1, designResonator(1090, 18, 48000), 1.0, true);  // F2
core.setStage(2, designResonator(2440, 18, 48000), 1.0, true);  // F3
core.setStage(3, designResonator(3500, 18, 48000), 1.0, true);  // F4
core.setStage(4, {}, 0.0, false);  // Muted
core.setStage(5, {}, 0.0, false);  // Muted
core.setStage(6, {}, 0.0, false);  // Muted

// 3. Set gains
core.setDrive(1.0f);
core.setMakeupGain(6.0f);

// 4. Process
for (int i = 0; i < numSamples; ++i) {
    output[i] = core.processSample(input[i]);
}
```

---

## References

- US5170369A - Dave Rossum - ARMAdillo encoding patent
- US10514883B2 - Multi-channel morphing digital filter patent  
- Peterson & Barney 1952 - Vowel formant frequencies
- Dattorro - Effect Design Part 1 (saturation)
- E-mu Morpheus/Audity 2000 manuals
